/**
 * Samuel Gonzalez Vazquez 
 * A01412958
 * Algoritmos Avanzados
 */
#include <iostream>
#include <vector>
#include <queue>
#include <utility>

using namespace std;


// Definición de direcciones para moverse en el laberinto (arriba, abajo, izquierda, derecha)
const int dx[] = { -1, 1, 0, 0 };
const int dy[] = { 0, 0, -1, 1 };

/**
 * Función para verificar si una celda es válida.
 * @param x: Coordenada x de la celda.
 * @param y: Coordenada y de la celda.
 * @param M: Número de filas del laberinto.
 * @param N: Número de columnas del laberinto.
 * @param maze: Matriz que representa el laberinto.
 * @param visited: Matriz que indica si una celda ha sido visitada.
 * @return true si la celda es válida, false en caso contrario.
 */
bool isValid(int x, int y, int M, int N, vector<vector<int>>& maze, vector<vector<bool>>& visited) {
    return x >= 0 && x < M && y >= 0 && y < N && maze[x][y] == 1 && !visited[x][y];
}

/**
 * Función de backtracking para encontrar un camino en el laberinto.
 * @param x: Coordenada x actual.
 * @param y: Coordenada y actual.
 * @param M: Número de filas del laberinto.
 * @param N: Número de columnas del laberinto.
 * @param maze: Matriz que representa el laberinto.
 * @param visited: Matriz que indica si una celda ha sido visitada.
 * @param path: Matriz que almacena el camino encontrado.
 * @return true si se encuentra un camino, false en caso contrario.
 */
bool backtracking(int x, int y, int M, int N, vector<vector<int>>& maze, vector<vector<bool>>& visited, vector<vector<int>>& path) {
    // Si llegamos a la meta, retornamos true
    if (x == M - 1 && y == N - 1) {
        path[x][y] = 1;
        return true;
    }

    // Marcamos la celda actual como visitada
    visited[x][y] = true;
    path[x][y] = 1;

    // Exploramos las 4 direcciones posibles
    for (int i = 0; i < 4; i++) {
        int nx = x + dx[i];
        int ny = y + dy[i];

        if (isValid(nx, ny, M, N, maze, visited)) {
            if (backtracking(nx, ny, M, N, maze, visited, path)) {
                return true;
            }
        }
    }

    // Si no se encuentra un camino, retrocedemos
    path[x][y] = 0;
    return false;
}

/**
 * Función de ramificación y poda para encontrar un camino en el laberinto usando BFS.
 * @param M: Número de filas del laberinto.
 * @param N: Número de columnas del laberinto.
 * @param maze: Matriz que representa el laberinto.
 * @param path: Matriz que almacena el camino encontrado.
 * @return true si se encuentra un camino, false en caso contrario.
 */
bool branchAndBound(int M, int N, vector<vector<int>>& maze, vector<vector<int>>& path) {
    queue<pair<int, int>> q;
    vector<vector<bool>> visited(M, vector<bool>(N, false));
    vector<vector<pair<int, int>>> parent(M, vector<pair<int, int>>(N, { -1, -1 }));

    q.push({ 0, 0 });
    visited[0][0] = true;

    while (!q.empty()) {
        auto current = q.front();
        q.pop();
        int x = current.first;
        int y = current.second;

        // Si llegamos a la meta, reconstruimos el camino
        if (x == M - 1 && y == N - 1) {
            while (x != -1 && y != -1) {
                path[x][y] = 1;
                auto p = parent[x][y];
                x = p.first;
                y = p.second;
            }
            return true;
        }

        // Exploramos las 4 direcciones posibles
        for (int i = 0; i < 4; i++) {
            int nx = x + dx[i];
            int ny = y + dy[i];

            if (isValid(nx, ny, M, N, maze, visited)) {
                visited[nx][ny] = true;
                q.push({ nx, ny });
                parent[nx][ny] = { x, y };
            }
        }
    }

    return false;
}

/**
 * Función para imprimir la matriz de camino.
 * @param M: Número de filas del laberinto.
 * @param N: Número de columnas del laberinto.
 * @param path: Matriz que representa el camino encontrado.
 */
void printPath(int M, int N, vector<vector<int>>& path) {
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            cout << path[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int M, N;
    cin >> M >> N;

    vector<vector<int>> maze(M, vector<int>(N));
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            cin >> maze[i][j];
        }
    }

    // Solución con Backtracking
    vector<vector<bool>> visitedBacktracking(M, vector<bool>(N, false));
    vector<vector<int>> pathBacktracking(M, vector<int>(N, 0));

    if (backtracking(0, 0, M, N, maze, visitedBacktracking, pathBacktracking)) {
        printPath(M, N, pathBacktracking);
    } else {
        cout << "No hay solucion con Backtracking" << endl;
    }

    cout << endl;

    // Solución con Ramificación y Poda
    vector<vector<int>> pathBranchAndBound(M, vector<int>(N, 0));

    if (branchAndBound(M, N, maze, pathBranchAndBound)) {
        printPath(M, N, pathBranchAndBound);
    } else {
        cout << "No hay solucin con Ramificacion y Poda" << endl;
    }

    return 0;
}